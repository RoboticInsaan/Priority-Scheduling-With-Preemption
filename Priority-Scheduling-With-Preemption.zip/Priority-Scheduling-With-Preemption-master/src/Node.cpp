 #include "../include/Node.h"
 Node::Node(int a=0,int b=0,int c=0,int d=0)
     {
         processno=a;
         priorityvalue=b;
         arrivaltime=c;
         bursttime=d;
     }
